import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from sklearn.tree import DecisionTreeClassifier # Import Decision Tree Classifier
from sklearn.tree import plot_tree
from sklearn.model_selection import train_test_split # Import train_test_split function
from sklearn import metrics
import numpy as stats
from sklearn.tree import export_graphviz
from six import StringIO
from IPython.display import Image
import pydotplus

col_names = ['NPG', 'PGL', 'DIA', 'TSF', 'INS', 'BMI', 'DPF', 'AGE', 'Diabetic']
feature_colomns = ['NPG', 'PGL', 'DIA', 'TSF', 'INS', 'BMI', 'DPF', 'AGE']
# get dataset
#dataset = pd.read_csv(r"C:\Users\Asus ZenBook\Desktop\DiabetesData (1).csv", header=1, names=col_names)
dataset = pd.read_csv(r"C:/Users/DiabetesData.csv", header=1, names=col_names)
#dataset2 = pd.read_csv(r"C:/Users/DiabetesData.csv", header=1, names=feature_colomns)

#dataset2 equals this line the double parantheses is basically a subset
dataset2 =dataset[['NPG', 'PGL', 'DIA', 'TSF', 'INS', 'BMI', 'DPF', 'AGE']]
#print(dataset.info())
print('distribution of the target (positive over negative)=' + str( round(((dataset['Diabetic']==1).sum()/(dataset['Diabetic']==0).sum())*100 , 2) ) + '%')
print('------')



# statistics
means = dataset2.mean()
for attribute, mean in means.items():
    print('Mean of', attribute + ':', mean)
    print('---')

# Calculate medians
medians = dataset2.median()
for attribute, median in medians.items():
    print('Median of', attribute + ':', median)
    print('---')

standardD = np.std(dataset2)
for attribute, std in zip(dataset2.columns, standardD):
    print('Standard deviation of', attribute + ':', std)
    print('-----')

min = dataset2.min()
max = dataset2.max()
for attribute in dataset2.columns:
    print('Minimum of', attribute + ':', min[attribute])

    print('Maximum of', attribute + ':', max[attribute])
    print('................')



#features with the target removed (independet)

X = dataset[feature_colomns]
y = dataset.Diabetic # the outcome (dependent)

#first model
x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=1, stratify= y)
#second model
# shuffling is default in this method
# stratify makes sure that the distribution in the test and training the same for the labels
x1_train, x1_test, y1_train, y1_test = train_test_split(X, y, test_size=0.5, random_state=1 , stratify= y)


# Create Decision Tree classifer object
# the random state allows the decision tree to start at a specific place
clf = DecisionTreeClassifier(random_state=7)
clf1 = DecisionTreeClassifier(random_state=7)

# Train Decision Tree Classifer
clf = clf.fit(x_train,y_train)
clf1 = clf1.fit(x1_train, y1_train)


#Predict the response for test dataset
predict1 = clf.predict(x_test)
predict2 = clf1.predict(x1_test)

print("Accuracy first: ",metrics.accuracy_score(y_test, predict1))
print("Accuracy second: ", metrics.accuracy_score(y1_test, predict2))


fig = plt.figure(figsize=(25,20))
plotTree=plot_tree(clf,
                   feature_names=feature_colomns,
                   # class_names=['Diabetic'],
                   filled=True)
fig.savefig("decistion_tree_M1.png", dpi=400)\


fig = plt.figure(figsize=(25,20))
plotTree=plot_tree(clf1,
                   feature_names=feature_colomns,
                   # class_names=['Diabetic'],
                   filled=True)
fig.savefig("decistion_tree_M2.png", dpi=400)

#
# dot_data = StringIO()
# export_graphviz(clf, out_file=dot_data, filled=True, rounded=True,  special_characters=True, feature_names = feature_colomns,class_names=['0','1'])
# graph = pydotplus.graph_from_dot_data(dot_data.getvalue())
# graph.write_png('diabetes.png')
# Image(graph.create_png())



